@extends('admin.layout')

@section('content')
    <div class="container-fluid d-flex justify-content-center">
        <img class="mt-5 w-100" src="{{ asset('images/logos/Logo-Eng.svg') }}">
    </div>
@endsection